﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestUnitarios
{
    [TestClass]
    public class PruebasConDBBandeja
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
